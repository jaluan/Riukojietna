function out = numdwr(all_samplexrf) 
%function that calculates the number density for elements of interest for
%each sample. Outputs into a file called all_samplesND in the Balculatorwr
%code
%
%Written by Allie Koester, Purdue University, June 2020
%koestea@purdue.edu

%file = input('Please enter the XRF file','s'); 
%FID = fopen(file);
%data = textscan(FID,'%s %n %n %n %n %n %n %n %n %n %n %n');
%input data is SiO2 TiO2 Al2O3 Fe2O3 FeO MnO MgO CaO Na2O K2O P2O5
%doesn't include Cr2O3, NiO, SrO, and BaO

%all_sample = cell2mat(data(2:end)); %matrix of all the sample data
%fclose(FID);

%check to make sure have correct input data before going further 
n=11;
if length(all_samplexrf) < n
    error('Error \nNumber of columns must be %d',n); %display error message
elseif length(all_samplexrf) > n
    error('Error \nNumber of columns must be %d',n);
end 

all_samplexrf = all_samplexrf./100; %convert into decimal form
num_samples = length(all_samplexrf);

all_sample_SiO2 = all_samplexrf(:,1); 
all_sample_TiO2 = all_samplexrf(:,2); 
all_sample_Al2O3 = all_samplexrf(:,3);
all_sample_Fe2O3 = all_samplexrf(:,4);
all_sample_FeO = all_samplexrf(:,5);
all_sample_MnO = all_samplexrf(:,6);
all_sample_MgO = all_samplexrf(:,7);
all_sample_CaO = all_samplexrf(:,8);
all_sample_NaO = all_samplexrf(:,9);
all_sample_K2O = all_samplexrf(:,10);
all_sample_P2O5 = all_samplexrf(:,11);

load Elfrac.mat
%first column is fraction of oxygen, second column is fraction of elements
%in the oxides (top to down) of SiO2, TiO2, Al2O3, Fe2O3, FeO, MnO, MgO, CaO, Na2O,
%K2O, P2O5
%need to use these values for measured oxides values from XRF data

NA = 6.02214129E23; %Avogadro's number

%sum up the data, normalize to 100%
for a =1:num_samples
    samplesum = sum(all_samplexrf,2); %input file, start with data 
%    %samplenorm = 100*samplesum./samplesum;
end 

%calculate number density for each element
%need to separate out from oxygen
Si = (Elfrac(1,2).*all_sample_SiO2.*NA)./28.085; %Si number density
Ti = (Elfrac(2,2).*all_sample_TiO2.*NA)./47.8670; %Ti ND
Al = (Elfrac(3,2).*all_sample_Al2O3.*NA)./26.9815; %Al ND 
Fe1 = (Elfrac(4,2).*all_sample_Fe2O3.*NA)./55.845; %Fe2O3 ND
Fe2 = (Elfrac(5,2).*all_sample_FeO.*NA)./55.845; %FeO ND
Mn = (Elfrac(6,2).*all_sample_MnO.*NA)./54.938004; %Mn ND
Mg = (Elfrac(7,2).*all_sample_MgO.*NA)./24.3055; %Mg ND
Ca = (Elfrac(8,2).*all_sample_CaO.*NA)./40.078; %Ca ND
Na = (Elfrac(9,2).*all_sample_NaO.*NA)./22.9898; %Na ND
K = (Elfrac(10,2).*all_sample_K2O.*NA)./39.0983; %K ND
P = (Elfrac(11,2).*all_sample_P2O5.*NA)./30.973762; %P ND

%normalize all the oxygen and sum together
normO1 = Elfrac(1,1).*all_sample_SiO2; %O
normO2 = Elfrac(2,1).*all_sample_TiO2;
normO3 = Elfrac(3,1).*all_sample_Al2O3;
normO4 = Elfrac(4,1).*all_sample_Fe2O3;
normO5 = Elfrac(5,1).*all_sample_FeO;
normO6 = Elfrac(6,1).*all_sample_MnO;
normO7 = Elfrac(7,1).*all_sample_MgO; 
normO8 = Elfrac(8,1).*all_sample_CaO;
normO9 = Elfrac(9,1).*all_sample_NaO;
normO10 = Elfrac(10,1).*all_sample_K2O; 
normO11 = Elfrac(11,1).*all_sample_P2O5; 

%for a = 1:num_samples
%    normO_total = (normO1(:,a) + normO2(:,a)) + normO3(:,a) + normO4(:,a)+ normO5(:,a)+ normO6(:,a)...
%        + normO7(:,a)+ normO8(:,a)+ normO9(:,a)+ normO10(:,a)+ normO11(:,a);
%end

normO_total = (normO1 + normO2 + normO3 + normO4+ normO5+ normO6...
        + normO7+ normO8+ normO9+ normO10+ normO11);
O = (normO_total*NA)./15.9994; %ND for oxygen

%save results in an array
%format: Si Ti Al Fe1 Fe2 Mn Mg Ca Na K P O
results = [Si, Ti, Al, Fe1, Fe2, Mn, Mg, Ca,Na, K, P, O];

out = results;
end 

